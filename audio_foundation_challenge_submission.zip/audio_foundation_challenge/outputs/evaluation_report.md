# Evaluation Report

## Metrics
- `asr_wer`: lower is better
- `tts_latency_seconds`: lower is better
- `fact_coverage_score`: higher is better

## Results

```
 setting  script_chars  tts_latency_seconds  asr_wer  fact_coverage_score
baseline           211               3.4157   0.3667                  0.0
improved           566              12.7812   0.6076                  1.0
```

## Quick Interpretation
- WER change (improved - baseline): +0.2409
- Latency change (improved - baseline): +9.3655 s
- Coverage change (improved - baseline): +1.0000