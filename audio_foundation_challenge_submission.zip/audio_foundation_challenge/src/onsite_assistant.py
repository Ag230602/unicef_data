from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, cast

import numpy as np
import soundfile as sf
import torch
from jiwer import wer
from transformers import (
    AutoModelForSeq2SeqLM,
    AutoProcessor,
    AutoTokenizer,
    MusicgenForConditionalGeneration,
    SpeechT5ForTextToSpeech,
    SpeechT5HifiGan,
    SpeechT5Processor,
    pipeline,
)


LANGUAGE_CODES = {
    "English": "eng_Latn",
    "French": "fra_Latn",
    "Spanish": "spa_Latn",
    "Portuguese": "por_Latn",
    "Arabic": "arb_Arab",
    "Hindi": "hin_Deva",
    "Swahili": "swh_Latn",
}


@dataclass
class SpeechComparison:
    clean_text: str
    noisy_text: str
    clean_wer: float | None
    noisy_wer: float | None


def build_music_prompt(
    user_goal: str,
    style_prompt: str,
    domain_context: str,
    intensity: int,
) -> str:
    return (
        f"Create instrumental music for {domain_context}. "
        f"Goal: {user_goal}. "
        f"Style: {style_prompt}. "
        f"Energy level {intensity}/10. "
        "No vocals, modern cinematic texture, emotionally supportive, clean mix."
    )


def add_white_noise(audio: np.ndarray, snr_db: float = 10.0) -> np.ndarray:
    audio = np.asarray(audio, dtype=np.float32)
    rms_signal = np.sqrt(np.mean(audio**2) + 1e-12)
    rms_noise = rms_signal / (10 ** (snr_db / 20))
    noise = np.random.normal(0.0, rms_noise, size=audio.shape).astype(np.float32)
    noisy = audio + noise
    return np.clip(noisy, -1.0, 1.0)


def normalize_text(text: str) -> str:
    return " ".join(text.lower().strip().split())


class WhisperTranscriber:
    def __init__(self, model_id: str = "openai/whisper-small") -> None:
        self.asr = pipeline(
            task="automatic-speech-recognition",
            model=model_id,
            device=0 if torch.cuda.is_available() else -1,
        )

    def transcribe_audio_array(self, audio: np.ndarray, sampling_rate: int) -> str:
        out = self.asr({"raw": audio, "sampling_rate": sampling_rate}, return_timestamps=True)
        if isinstance(out, dict):
            return str(out.get("text", "")).strip()
        return str(out).strip()


class MusicGenGenerator:
    def __init__(self, model_id: str = "facebook/musicgen-small") -> None:
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.processor = AutoProcessor.from_pretrained(model_id)
        self.model: Any = MusicgenForConditionalGeneration.from_pretrained(model_id)
        self.model = self.model.to(self.device)

    def generate(self, prompt: str, duration_seconds: int = 8) -> tuple[np.ndarray, int]:
        token_budget = max(128, min(1024, duration_seconds * 64))
        inputs = self.processor(text=[prompt], padding=True, return_tensors="pt")
        inputs = {k: v.to(self.device) for k, v in inputs.items()}
        with torch.inference_mode():
            audio_values = self.model.generate(**inputs, max_new_tokens=token_budget)
        cfg = getattr(self.model.config, "audio_encoder", {})
        sample_rate = int(getattr(cfg, "sampling_rate", 32000))
        audio = audio_values[0, 0].detach().cpu().numpy().astype(np.float32)
        return audio, sample_rate


class NLLBTranslator:
    def __init__(self, model_id: str = "facebook/nllb-200-distilled-600M") -> None:
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.tokenizer = AutoTokenizer.from_pretrained(model_id)
        self.model = AutoModelForSeq2SeqLM.from_pretrained(model_id).to(self.device)

    def translate(self, text: str, source_language: str, target_language: str) -> str:
        src = LANGUAGE_CODES[source_language]
        tgt = LANGUAGE_CODES[target_language]
        self.tokenizer.src_lang = src
        encoded = self.tokenizer(text, return_tensors="pt")
        encoded = {k: v.to(self.device) for k, v in encoded.items()}
        with torch.inference_mode():
            generated = self.model.generate(
                **encoded,
                forced_bos_token_id=self.tokenizer.convert_tokens_to_ids(tgt),
                max_new_tokens=256,
            )
        return self.tokenizer.batch_decode(generated, skip_special_tokens=True)[0]


class SpeechT5VoiceAssistant:
    def __init__(
        self,
        tts_model_id: str = "microsoft/speecht5_tts",
        vocoder_id: str = "microsoft/speecht5_hifigan",
    ) -> None:
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.processor = SpeechT5Processor.from_pretrained(tts_model_id)
        self.model: Any = SpeechT5ForTextToSpeech.from_pretrained(tts_model_id)
        self.model = self.model.to(self.device)
        self.vocoder: Any = SpeechT5HifiGan.from_pretrained(vocoder_id)
        self.vocoder = self.vocoder.to(self.device)

    def default_embedding(self) -> torch.Tensor:
        return torch.zeros((1, 512), dtype=torch.float32, device=self.device)

    def embedding_from_reference(self, reference_wav_path: str | Path) -> torch.Tensor:
        # Lightweight voice cloning proxy: derive deterministic embedding from audio statistics.
        # This avoids requiring extra heavyweight speaker-encoder models during onsite demos.
        audio, sr = sf.read(str(reference_wav_path))
        audio = np.asarray(audio, dtype=np.float32)
        if audio.ndim > 1:
            audio = np.mean(audio, axis=1)

        if len(audio) == 0:
            return self.default_embedding()

        stats = np.array(
            [
                float(np.mean(audio)),
                float(np.std(audio)),
                float(np.max(audio)),
                float(np.min(audio)),
                float(np.percentile(audio, 25)),
                float(np.percentile(audio, 50)),
                float(np.percentile(audio, 75)),
                float(sr / 48000.0),
            ],
            dtype=np.float32,
        )
        repeated = np.resize(stats, 512)
        emb = torch.tensor(repeated, dtype=torch.float32, device=self.device).unsqueeze(0)
        emb = torch.nn.functional.normalize(emb, dim=-1)
        return emb

    def synthesize(self, text: str, speaker_embedding: torch.Tensor | None = None) -> tuple[np.ndarray, int]:
        emb = speaker_embedding if speaker_embedding is not None else self.default_embedding()
        emb = cast(torch.FloatTensor, emb)
        inputs = cast(dict[str, torch.Tensor], self.processor(text=text, return_tensors="pt"))
        input_ids = inputs.get("input_ids")
        if input_ids is None:
            raise ValueError("Failed to tokenize input text.")
        input_ids = input_ids.to(self.device)

        with torch.inference_mode():
            out = self.model.generate_speech(
                input_ids=input_ids,
                speaker_embeddings=emb,
                vocoder=self.vocoder,
            )
        speech = out[0] if isinstance(out, tuple) else out
        return speech.detach().cpu().numpy().astype(np.float32), 16000


def compare_clean_vs_noisy(
    transcriber: WhisperTranscriber,
    audio: np.ndarray,
    sampling_rate: int,
    snr_db: float,
    reference_text: str | None = None,
) -> SpeechComparison:
    noisy = add_white_noise(audio, snr_db=snr_db)
    clean_text = transcriber.transcribe_audio_array(audio, sampling_rate)
    noisy_text = transcriber.transcribe_audio_array(noisy, sampling_rate)

    clean_wer = None
    noisy_wer = None
    if reference_text and reference_text.strip():
        ref = normalize_text(reference_text)
        clean_wer = float(wer(ref, normalize_text(clean_text)))
        noisy_wer = float(wer(ref, normalize_text(noisy_text)))

    return SpeechComparison(
        clean_text=clean_text,
        noisy_text=noisy_text,
        clean_wer=clean_wer,
        noisy_wer=noisy_wer,
    )
